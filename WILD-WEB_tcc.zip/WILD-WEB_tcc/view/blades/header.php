<?php Include("blades/navbar.php")?>

<!--Header-->
<header id="home">
    <div class="quicksand-font container content">
        <h1 style="font-weight: 500;">W I L D</h1>
        <p style="font-weight: 400;">Proteção de animais silvestres no <span style="color: #EDA011;">Vale do Ribeira</span></p>
    </div>
</header>
